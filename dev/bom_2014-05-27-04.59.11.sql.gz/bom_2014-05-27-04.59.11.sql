--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: auth_climateanalyseruser; Type: TABLE; Schema: public; Owner: bom; Tablespace: 
--

CREATE TABLE auth_climateanalyseruser (
    id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.auth_climateanalyseruser OWNER TO bom;

--
-- Name: auth_climateanalyseruser_id_seq; Type: SEQUENCE; Schema: public; Owner: bom
--

CREATE SEQUENCE auth_climateanalyseruser_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_climateanalyseruser_id_seq OWNER TO bom;

--
-- Name: auth_climateanalyseruser_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bom
--

ALTER SEQUENCE auth_climateanalyseruser_id_seq OWNED BY auth_climateanalyseruser.id;


--
-- Name: auth_climateanalyseruser_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bom
--

SELECT pg_catalog.setval('auth_climateanalyseruser_id_seq', 1, false);


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_group_id_seq OWNED BY auth_group.id;


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_group_permissions_id_seq OWNED BY auth_group_permissions.id;


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_permission (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_permission_id_seq OWNED BY auth_permission.id;


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_permission_id_seq', 33, true);


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone NOT NULL,
    is_superuser boolean NOT NULL,
    username character varying(30) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(30) NOT NULL,
    email character varying(75) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO postgres;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO postgres;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO postgres;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_user_groups_id_seq OWNED BY auth_user_groups.id;


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO postgres;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_user_id_seq OWNED BY auth_user.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_user_id_seq', 2, true);


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO postgres;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_user_user_permissions_id_seq OWNED BY auth_user_user_permissions.id;


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_user_user_permissions_id_seq', 13, true);


--
-- Name: climateanalyser_computation; Type: TABLE; Schema: public; Owner: bom; Tablespace: 
--

CREATE TABLE climateanalyser_computation (
    id integer NOT NULL,
    created_by_id integer NOT NULL,
    created_date timestamp with time zone NOT NULL,
    completed_date timestamp with time zone,
    calculation character varying(100) NOT NULL
);


ALTER TABLE public.climateanalyser_computation OWNER TO bom;

--
-- Name: climateanalyser_computation_id_seq; Type: SEQUENCE; Schema: public; Owner: bom
--

CREATE SEQUENCE climateanalyser_computation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.climateanalyser_computation_id_seq OWNER TO bom;

--
-- Name: climateanalyser_computation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bom
--

ALTER SEQUENCE climateanalyser_computation_id_seq OWNED BY climateanalyser_computation.id;


--
-- Name: climateanalyser_computation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bom
--

SELECT pg_catalog.setval('climateanalyser_computation_id_seq', 10, true);


--
-- Name: climateanalyser_datafile; Type: TABLE; Schema: public; Owner: bom; Tablespace: 
--

CREATE TABLE climateanalyser_datafile (
    id integer NOT NULL,
    path character varying(1000) NOT NULL,
    computation_id integer NOT NULL
);


ALTER TABLE public.climateanalyser_datafile OWNER TO bom;

--
-- Name: climateanalyser_datafile_id_seq; Type: SEQUENCE; Schema: public; Owner: bom
--

CREATE SEQUENCE climateanalyser_datafile_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.climateanalyser_datafile_id_seq OWNER TO bom;

--
-- Name: climateanalyser_datafile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bom
--

ALTER SEQUENCE climateanalyser_datafile_id_seq OWNED BY climateanalyser_datafile.id;


--
-- Name: climateanalyser_datafile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bom
--

SELECT pg_catalog.setval('climateanalyser_datafile_id_seq', 18, true);


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    user_id integer NOT NULL,
    content_type_id integer,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE django_admin_log_id_seq OWNED BY django_admin_log.id;


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('django_admin_log_id_seq', 2, true);


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE django_content_type (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE django_content_type_id_seq OWNED BY django_content_type.id;


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('django_content_type_id_seq', 11, true);


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO postgres;

--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bom
--

ALTER TABLE ONLY auth_climateanalyseruser ALTER COLUMN id SET DEFAULT nextval('auth_climateanalyseruser_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group ALTER COLUMN id SET DEFAULT nextval('auth_group_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('auth_group_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_permission ALTER COLUMN id SET DEFAULT nextval('auth_permission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user ALTER COLUMN id SET DEFAULT nextval('auth_user_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_groups ALTER COLUMN id SET DEFAULT nextval('auth_user_groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('auth_user_user_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bom
--

ALTER TABLE ONLY climateanalyser_computation ALTER COLUMN id SET DEFAULT nextval('climateanalyser_computation_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bom
--

ALTER TABLE ONLY climateanalyser_datafile ALTER COLUMN id SET DEFAULT nextval('climateanalyser_datafile_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_admin_log ALTER COLUMN id SET DEFAULT nextval('django_admin_log_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_content_type ALTER COLUMN id SET DEFAULT nextval('django_content_type_id_seq'::regclass);


--
-- Data for Name: auth_climateanalyseruser; Type: TABLE DATA; Schema: public; Owner: bom
--

COPY auth_climateanalyseruser (id, user_id) FROM stdin;
\.


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	1	add_logentry
2	Can change log entry	1	change_logentry
3	Can delete log entry	1	delete_logentry
4	Can add permission	2	add_permission
5	Can change permission	2	change_permission
6	Can delete permission	2	delete_permission
7	Can add group	3	add_group
8	Can change group	3	change_group
9	Can delete group	3	delete_group
10	Can add user	4	add_user
11	Can change user	4	change_user
12	Can delete user	4	delete_user
13	Can add content type	5	add_contenttype
14	Can change content type	5	change_contenttype
15	Can delete content type	5	delete_contenttype
16	Can add session	6	add_session
17	Can change session	6	change_session
18	Can delete session	6	delete_session
19	Can add climate analyser user	7	add_climateanalyseruser
20	Can change climate analyser user	7	change_climateanalyseruser
21	Can delete climate analyser user	7	delete_climateanalyseruser
28	Can add computation	10	add_computation
29	Can change computation	10	change_computation
30	Can delete computation	10	delete_computation
31	Can add data file	11	add_datafile
32	Can change data file	11	change_datafile
33	Can delete data file	11	delete_datafile
\.


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
2	pbkdf2_sha256$12000$Nnwo3LbLULCj$oIcLtmfwJwBb16vHV1AGgLTCs9SQtW/oW0RovwJ5ctI=	2014-05-21 08:32:09.595919+00	f	test1	Test	User1	s3334276@student.rmit.edu.au	f	t	2014-05-20 05:50:43+00
1	pbkdf2_sha256$12000$5sBCIUVoxQja$hJK75FEhoYec1gYcgMlzEEaA8zFAfeIHuatbGTaL5aY=	2014-05-27 03:31:23.268109+00	t	admin			s3334276@student.rmit.edu.au	t	t	2014-04-15 04:39:29.796747+00
\.


--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
1	2	32
2	2	33
3	2	11
4	2	13
5	2	14
6	2	15
7	2	16
8	2	17
9	2	18
10	2	28
11	2	29
12	2	30
13	2	31
\.


--
-- Data for Name: climateanalyser_computation; Type: TABLE DATA; Schema: public; Owner: bom
--

COPY climateanalyser_computation (id, created_by_id, created_date, completed_date, calculation) FROM stdin;
1	1	2014-05-17 04:49:55.803809+00	\N	correlate
2	1	2014-05-17 04:50:13.98846+00	\N	correlate
3	1	2014-05-17 04:50:41.803652+00	\N	correlate
4	1	2014-05-17 04:51:35.365258+00	\N	correlate
5	1	2014-05-17 05:15:07.666021+00	\N	correlate
6	1	2014-05-20 05:39:57.996144+00	\N	correlate
7	2	2014-05-21 08:34:15.443456+00	\N	correlate
8	1	2014-05-27 03:35:00.912443+00	\N	correlate
9	1	2014-05-27 03:36:37.707049+00	\N	correlate
10	2	2014-05-27 04:09:32.276816+00	\N	
\.


--
-- Data for Name: climateanalyser_datafile; Type: TABLE DATA; Schema: public; Owner: bom
--

COPY climateanalyser_datafile (id, path, computation_id) FROM stdin;
1	happy data file 1	2
2	happy data file 2	2
3	happy data file 1	3
4	happy data file 2	3
5	happy data file 1	4
6	happy data file 2	4
7	aaa	5
8	bbb	5
9	http://130.56.248.143/samples/sample_1D.nc	6
10	http://130.56.248.143/samples/sample_3D.nc	6
11	sdfsdf	7
12	fdsdf	7
13	test1	8
14	test2	8
15	test123	9
16	test123	9
17	file1	10
18	file2	10
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_admin_log (id, action_time, user_id, content_type_id, object_id, object_repr, action_flag, change_message) FROM stdin;
1	2014-05-20 05:50:43.274397+00	1	4	2	test1	1	
2	2014-05-20 05:52:20.487972+00	1	4	2	test1	2	Changed first_name, last_name, email and user_permissions.
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_content_type (id, name, app_label, model) FROM stdin;
1	log entry	admin	logentry
2	permission	auth	permission
3	group	auth	group
4	user	auth	user
5	content type	contenttypes	contenttype
6	session	sessions	session
7	climate analyser user	auth	climateanalyseruser
10	computation	climateanalyser	computation
11	data file	climateanalyser	datafile
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_session (session_key, session_data, expire_date) FROM stdin;
am548q4s3ih6wp0d3reik11jf5c80f88	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-05-27 02:03:24.413035+00
7ld81a95jirfsz48p5k7tlv19aquoaxr	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-05-27 02:03:24.552297+00
rw6g7x26g2hdv4hn76v0h3d9370h5g2u	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-06-03 05:41:04.95315+00
fi9f6trhr1swkg0csvl0b7hfibbnb704	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-06-03 05:41:05.050022+00
s9tktuextf4q02h3zbt8fev4ofh1a5xx	N2VkZjVjZWYzNjYyMGUwYzQyNDdlNGI5YThiYmJkOTRhMjcyMGQ1ZDp7Il9hdXRoX3VzZXJfaWQiOjIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=	2014-06-03 08:21:10.115128+00
ag2ifiy5q2kkahx66j0xqujzlxkyiaz2	MzY0ODY3ZjU5OWNkMTdhMDU3YTdkNDY1NjRmMTBlNmRlYzFkOTdmNzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6Mn0=	2014-06-04 08:32:09.598481+00
rpm0pjt4e3shm2f31zlutwrnf06fol37	NzhjOGIwY2EzYTQ0YzllNWJkMDhiN2VkMTM3MGM3YTAyMGM3YjZhMTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6MX0=	2014-06-10 03:31:23.270545+00
\.


--
-- Name: auth_climateanalyseruser_pkey; Type: CONSTRAINT; Schema: public; Owner: bom; Tablespace: 
--

ALTER TABLE ONLY auth_climateanalyseruser
    ADD CONSTRAINT auth_climateanalyseruser_pkey PRIMARY KEY (id);


--
-- Name: auth_climateanalyseruser_user_id_key; Type: CONSTRAINT; Schema: public; Owner: bom; Tablespace: 
--

ALTER TABLE ONLY auth_climateanalyseruser
    ADD CONSTRAINT auth_climateanalyseruser_user_id_key UNIQUE (user_id);


--
-- Name: auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions_group_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_key UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission_content_type_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_key UNIQUE (content_type_id, codename);


--
-- Name: auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_key UNIQUE (user_id, group_id);


--
-- Name: auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_key UNIQUE (user_id, permission_id);


--
-- Name: auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: climateanalyser_computation_pkey; Type: CONSTRAINT; Schema: public; Owner: bom; Tablespace: 
--

ALTER TABLE ONLY climateanalyser_computation
    ADD CONSTRAINT climateanalyser_computation_pkey PRIMARY KEY (id);


--
-- Name: climateanalyser_datafile_pkey; Type: CONSTRAINT; Schema: public; Owner: bom; Tablespace: 
--

ALTER TABLE ONLY climateanalyser_datafile
    ADD CONSTRAINT climateanalyser_datafile_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type_app_label_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_app_label_key UNIQUE (app_label, model);


--
-- Name: django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: auth_group_name_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_group_name_like ON auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_group_permissions_group_id ON auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_group_permissions_permission_id ON auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_permission_content_type_id ON auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_user_groups_group_id ON auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_user_groups_user_id ON auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_permission_id ON auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_user_id ON auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_user_username_like ON auth_user USING btree (username varchar_pattern_ops);


--
-- Name: climateanalyser_computation_created_by_id; Type: INDEX; Schema: public; Owner: bom; Tablespace: 
--

CREATE INDEX climateanalyser_computation_created_by_id ON climateanalyser_computation USING btree (created_by_id);


--
-- Name: climateanalyser_datafile_computation_id; Type: INDEX; Schema: public; Owner: bom; Tablespace: 
--

CREATE INDEX climateanalyser_datafile_computation_id ON climateanalyser_datafile USING btree (computation_id);


--
-- Name: django_admin_log_content_type_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX django_admin_log_content_type_id ON django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX django_admin_log_user_id ON django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX django_session_expire_date ON django_session USING btree (expire_date);


--
-- Name: django_session_session_key_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX django_session_session_key_like ON django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: auth_climateanalyseruser_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: bom
--

ALTER TABLE ONLY auth_climateanalyseruser
    ADD CONSTRAINT auth_climateanalyseruser_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_fkey FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: climateanalyser_computation_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: bom
--

ALTER TABLE ONLY climateanalyser_computation
    ADD CONSTRAINT climateanalyser_computation_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: climateanalyser_datafile_computation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: bom
--

ALTER TABLE ONLY climateanalyser_datafile
    ADD CONSTRAINT climateanalyser_datafile_computation_id_fkey FOREIGN KEY (computation_id) REFERENCES climateanalyser_computation(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: content_type_id_refs_id_93d2d1f8; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT content_type_id_refs_id_93d2d1f8 FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: content_type_id_refs_id_d043b34a; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT content_type_id_refs_id_d043b34a FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: group_id_refs_id_f4b32aac; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT group_id_refs_id_f4b32aac FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_40c41112; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT user_id_refs_id_40c41112 FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_4dc23c39; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT user_id_refs_id_4dc23c39 FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_c0d12874; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT user_id_refs_id_c0d12874 FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- Name: auth_group; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE auth_group FROM PUBLIC;
REVOKE ALL ON TABLE auth_group FROM postgres;
GRANT ALL ON TABLE auth_group TO postgres;
GRANT ALL ON TABLE auth_group TO bom;


--
-- Name: auth_group_id_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON SEQUENCE auth_group_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE auth_group_id_seq FROM postgres;
GRANT ALL ON SEQUENCE auth_group_id_seq TO postgres;
GRANT ALL ON SEQUENCE auth_group_id_seq TO bom;


--
-- Name: auth_group_permissions; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE auth_group_permissions FROM PUBLIC;
REVOKE ALL ON TABLE auth_group_permissions FROM postgres;
GRANT ALL ON TABLE auth_group_permissions TO postgres;
GRANT ALL ON TABLE auth_group_permissions TO bom;


--
-- Name: auth_group_permissions_id_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON SEQUENCE auth_group_permissions_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE auth_group_permissions_id_seq FROM postgres;
GRANT ALL ON SEQUENCE auth_group_permissions_id_seq TO postgres;
GRANT ALL ON SEQUENCE auth_group_permissions_id_seq TO bom;


--
-- Name: auth_permission; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE auth_permission FROM PUBLIC;
REVOKE ALL ON TABLE auth_permission FROM postgres;
GRANT ALL ON TABLE auth_permission TO postgres;
GRANT ALL ON TABLE auth_permission TO bom;


--
-- Name: auth_permission_id_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON SEQUENCE auth_permission_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE auth_permission_id_seq FROM postgres;
GRANT ALL ON SEQUENCE auth_permission_id_seq TO postgres;
GRANT ALL ON SEQUENCE auth_permission_id_seq TO bom;


--
-- Name: auth_user; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE auth_user FROM PUBLIC;
REVOKE ALL ON TABLE auth_user FROM postgres;
GRANT ALL ON TABLE auth_user TO postgres;
GRANT ALL ON TABLE auth_user TO bom;


--
-- Name: auth_user_groups; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE auth_user_groups FROM PUBLIC;
REVOKE ALL ON TABLE auth_user_groups FROM postgres;
GRANT ALL ON TABLE auth_user_groups TO postgres;
GRANT ALL ON TABLE auth_user_groups TO bom;


--
-- Name: auth_user_groups_id_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON SEQUENCE auth_user_groups_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE auth_user_groups_id_seq FROM postgres;
GRANT ALL ON SEQUENCE auth_user_groups_id_seq TO postgres;
GRANT ALL ON SEQUENCE auth_user_groups_id_seq TO bom;


--
-- Name: auth_user_id_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON SEQUENCE auth_user_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE auth_user_id_seq FROM postgres;
GRANT ALL ON SEQUENCE auth_user_id_seq TO postgres;
GRANT ALL ON SEQUENCE auth_user_id_seq TO bom;


--
-- Name: auth_user_user_permissions; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE auth_user_user_permissions FROM PUBLIC;
REVOKE ALL ON TABLE auth_user_user_permissions FROM postgres;
GRANT ALL ON TABLE auth_user_user_permissions TO postgres;
GRANT ALL ON TABLE auth_user_user_permissions TO bom;


--
-- Name: auth_user_user_permissions_id_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON SEQUENCE auth_user_user_permissions_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE auth_user_user_permissions_id_seq FROM postgres;
GRANT ALL ON SEQUENCE auth_user_user_permissions_id_seq TO postgres;
GRANT ALL ON SEQUENCE auth_user_user_permissions_id_seq TO bom;


--
-- Name: django_admin_log; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE django_admin_log FROM PUBLIC;
REVOKE ALL ON TABLE django_admin_log FROM postgres;
GRANT ALL ON TABLE django_admin_log TO postgres;
GRANT ALL ON TABLE django_admin_log TO bom;


--
-- Name: django_admin_log_id_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON SEQUENCE django_admin_log_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE django_admin_log_id_seq FROM postgres;
GRANT ALL ON SEQUENCE django_admin_log_id_seq TO postgres;
GRANT ALL ON SEQUENCE django_admin_log_id_seq TO bom;


--
-- Name: django_content_type; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE django_content_type FROM PUBLIC;
REVOKE ALL ON TABLE django_content_type FROM postgres;
GRANT ALL ON TABLE django_content_type TO postgres;
GRANT ALL ON TABLE django_content_type TO bom;


--
-- Name: django_content_type_id_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON SEQUENCE django_content_type_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE django_content_type_id_seq FROM postgres;
GRANT ALL ON SEQUENCE django_content_type_id_seq TO postgres;
GRANT ALL ON SEQUENCE django_content_type_id_seq TO bom;


--
-- Name: django_session; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE django_session FROM PUBLIC;
REVOKE ALL ON TABLE django_session FROM postgres;
GRANT ALL ON TABLE django_session TO postgres;
GRANT ALL ON TABLE django_session TO bom;


--
-- PostgreSQL database dump complete
--

